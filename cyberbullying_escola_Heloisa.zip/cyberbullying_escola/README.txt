CYBERBULLYING NA ESCOLA
Projeto web educativo — comunidade escolar com 1.500 alunos

Arquivos:
- index.html
- style.css
- script.js
- assets/*.svg

Como abrir:
1. Extraia o arquivo ZIP.
2. Abra index.html no navegador.
3. Não é necessário servidor ou internet para visualizar a página e as ilustrações.
4. Os links das fontes oficiais precisam de internet para serem acessados.

Acessibilidade:
- link "Pular para o conteúdo";
- navegação por teclado e foco visível;
- aumento/redução/restauração da fonte;
- modo de alto contraste;
- leitura da página usando a API de síntese de voz do navegador;
- textos alternativos nas imagens;
- HTML semântico e rótulos ARIA.

Fontes oficiais:
UNICEF Brasil — https://www.unicef.org/brazil/cyberbullying-o-que-eh-e-como-para-lo
Lei 13.185/2015 — https://planalto.gov.br/ccivil_03/_ato2015-2018/2015/lei/l13185.htm
Lei 14.811/2024 — https://planalto.gov.br/ccivil_03/_ato2023-2026/2024/lei/l14811.htm
Ministério dos Direitos Humanos — https://www.gov.br/mdh/
