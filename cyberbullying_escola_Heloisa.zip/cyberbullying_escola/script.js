const body = document.body;
let fontLevel = 0;
const fontSteps = [18, 19.5, 21, 23, 25];

document.getElementById("fontIncrease").addEventListener("click", () => {
  fontLevel = Math.min(fontLevel + 1, fontSteps.length - 1);
  body.style.fontSize = fontSteps[fontLevel] + "px";
});
document.getElementById("fontDecrease").addEventListener("click", () => {
  fontLevel = Math.max(fontLevel - 1, 0);
  body.style.fontSize = fontSteps[fontLevel] + "px";
});
document.getElementById("fontReset").addEventListener("click", () => {
  fontLevel = 0;
  body.style.fontSize = "18px";
});

const contrastButton = document.getElementById("contrastToggle");
contrastButton.addEventListener("click", () => {
  const enabled = body.classList.toggle("high-contrast");
  contrastButton.setAttribute("aria-pressed", enabled ? "true" : "false");
});

const readButton = document.getElementById("readPage");
const stopButton = document.getElementById("stopReading");

readButton.addEventListener("click", () => {
  if (!("speechSynthesis" in window)) {
    alert("Seu navegador não oferece leitura de texto por voz.");
    return;
  }
  window.speechSynthesis.cancel();
  const main = document.getElementById("conteudo");
  const text = main.innerText;
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "pt-BR";
  utterance.rate = 0.95;
  window.speechSynthesis.speak(utterance);
});

stopButton.addEventListener("click", () => {
  if ("speechSynthesis" in window) window.speechSynthesis.cancel();
});
